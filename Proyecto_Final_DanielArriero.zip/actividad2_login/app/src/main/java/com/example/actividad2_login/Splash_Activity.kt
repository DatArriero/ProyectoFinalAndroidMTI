package com.example.actividad2_login

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler

class Splash_Activity : AppCompatActivity() {
    val SPLASH_TIME_OUT = 5000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        Handler().postDelayed(object : Runnable{
            override fun run() {
                val home = Intent(this@Splash_Activity, login::class.java)
                startActivity(home)
                finish()
            }
        },SPLASH_TIME_OUT.toLong())
    }
}
