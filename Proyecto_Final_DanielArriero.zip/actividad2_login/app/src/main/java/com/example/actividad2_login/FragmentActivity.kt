package com.example.actividad2_login

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.FloatingActionButton
import android.support.design.widget.TabLayout
import android.support.v4.view.ViewPager
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*

class FragmentActivity : AppCompatActivity() {

    private lateinit var tabs: TabLayout
    private lateinit var viewpager: ViewPager
    private lateinit var fbEjemplo: FloatingActionButton


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fragment)

        tabs = findViewById(R.id.tabs)
        viewpager = findViewById(R.id.viewpager)
        fbEjemplo = findViewById(R.id.fbEjemplo)

        val adapter = ParentPagerAdapter(supportFragmentManager)
        viewpager.adapter = adapter
        tabs.setupWithViewPager(viewpager)



        fbEjemplo.setOnClickListener{

            var intent = Intent(this, perfilActivity ::class.java)
            startActivity(intent)
        }
    }


}
