package com.example.actividad2_login

import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.jetbrains.anko.doAsync
import org.json.JSONObject

class ActivityRecycler : AppCompatActivity() {

    lateinit var recyclercalls: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recycler)

        //Configuramos la orientacion del RecyclerView
        val layoutManager = LinearLayoutManager(this)
        layoutManager.orientation = LinearLayoutManager.VERTICAL

        recyclercalls = findViewById(R.id.recyclercall)
        recyclercalls.layoutManager = layoutManager



        //Si se va a hacer el llenado dinamico, llamamos a la funcion aqui
        getDataFromUrl(this)
    }




    //Aqui se llenaria la lista si hacemos la peticion al Servicio Web
    private fun getDataFromUrl(context: Context){

        doAsync {

            //Variable tipo RequestQueue -> Crea una peticion Volley
            val requestQueue = Volley.newRequestQueue(context)

            //Paso de parametros para crear el REQUEST
            var strRequest = object : StringRequest(Method.POST, "http://www.mocky.io/v2/5cf0b179300000540000ba01", Response.Listener {
                    s-> Log.e("TAG", s.toString())

                //Respuesta del REQUEST aqui...
                val jsonResponse = JSONObject(s)

                //Declarar la variable de Lista fuera del FOR para llenarla posteriormente
                var listaObjetos = listOf<Calls>()


                //Nota: Investigar como funciona el FOR en Kotlin....
                for (i in 0 until jsonResponse.getJSONArray("Calls").length()) {
                    listaObjetos += Calls(
                        jsonResponse.getJSONArray("Calls").getJSONObject(i).getString("nombre"),
                        jsonResponse.getJSONArray("Calls").getJSONObject(i).getString("texto"),
                        jsonResponse.getJSONArray("Calls").getJSONObject(i).getString("hora")
                    )

                }




                //Aqui, una vez llenada la lista, se la pasamos al adapter y posteriormente se le asigna al RecyclerView
                var adapter = CallsAdapter(applicationContext, listaObjetos)
                recyclercalls.adapter = adapter

                //NOTA: NO olviden agregar el siguiente permiso en el Manifest:
                //<uses-permission android:nombre="android.permission.INTERNET"/>



            }, Response.ErrorListener {
                //Imprime el error en caso de existir
                    e-> Log.e("TAG", e.toString())
            }){}

            //Ejectuar la peticion aqui...
            requestQueue.add(strRequest)
        }
    }
}