package com.example.actividad2_login

class Conversaciones(var nombre:String, var texto:String, var hora:String, var imagen:Int) {
}