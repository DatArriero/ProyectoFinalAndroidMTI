package com.example.actividad2_login

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.bumptech.glide.Glide

class AdapterConversaciones (var list:ArrayList<Conversaciones>): RecyclerView.Adapter<AdapterConversaciones.ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.content_item_conver, parent, false)
        return ViewHolder(v)
    }

    override fun getItemCount(): Int {
        return list.size
    }

    override fun onBindViewHolder(holder: AdapterConversaciones.ViewHolder, p1: Int) {
        holder.bindItems(list[p1])
    }

    class ViewHolder(view:View):RecyclerView.ViewHolder(view) {
        fun bindItems(data: Conversaciones) {
            val nombre: TextView = itemView.findViewById(R.id.nombrecalls)
            val texto: TextView = itemView.findViewById(R.id.textocalls)
            val hora: TextView = itemView.findViewById(R.id.horacalls)
            val imagen: ImageView = itemView.findViewById(R.id.imagen)

            nombre.text = data.nombre
            texto.text = data.texto.toString()
            hora.text=data.hora

            Glide.with(itemView.context).load(data.imagen).into(imagen)

            itemView.setOnClickListener {
                Toast.makeText(itemView.context, "Conversacion de ${data.nombre}", Toast.LENGTH_LONG).show()
            }

        }
    }
}
