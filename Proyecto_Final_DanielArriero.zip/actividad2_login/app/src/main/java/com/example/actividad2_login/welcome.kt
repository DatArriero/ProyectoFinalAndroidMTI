package com.example.actividad2_login

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.TextView

class welcome : AppCompatActivity() {

    private lateinit var txtName : TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome)

        var extras: Bundle = intent.extras
        var res:String = extras.getString("name")
        txtName = findViewById(R.id.txtNombre)
        /*var prefs = getSharedPreferences("dataUser", MODE_PRIVATE)
        val usuario = prefs.getString("user", "no-data")*/
        txtName.setText(res)

    }
}