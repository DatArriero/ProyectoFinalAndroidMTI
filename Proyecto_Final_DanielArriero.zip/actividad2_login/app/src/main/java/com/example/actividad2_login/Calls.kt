package com.example.actividad2_login


class Calls(var nombre: String, var texto: String, var hora: String) {

}