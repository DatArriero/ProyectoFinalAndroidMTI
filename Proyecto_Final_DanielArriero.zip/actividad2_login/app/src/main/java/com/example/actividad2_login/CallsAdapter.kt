package com.example.actividad2_login

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import kotlinx.android.synthetic.main.card_example.view.*

class CallsAdapter (val context: Context, val listCalls: List<Calls>) : RecyclerView.Adapter<CallsAdapter.CallsViewHolder>() {

    override fun onCreateViewHolder(p0: ViewGroup, p1: Int): CallsViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.card_example, p0, false)
        return CallsViewHolder(view)
    }

    override fun getItemCount(): Int {
        return listCalls.size
    }

    override fun onBindViewHolder(p0: CallsViewHolder, p1: Int) {
        p0.setData(listCalls[p1], p1)
    }

    inner class CallsViewHolder (itemView : View) : RecyclerView.ViewHolder(itemView){

        fun setData(calls : Calls, pos : Int){
            itemView.nombre.text = calls.nombre
            itemView.texto.text = calls.texto
            itemView.hora.text = calls.hora


        }
    }
}