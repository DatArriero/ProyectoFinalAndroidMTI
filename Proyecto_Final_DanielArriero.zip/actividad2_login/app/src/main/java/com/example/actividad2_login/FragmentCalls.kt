package com.example.actividad2_login

import android.app.PendingIntent.getActivity
import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import org.jetbrains.anko.doAsync

class FragmentCalls : Fragment() {


    companion object {
        fun newInstance(): FragmentCalls{
            return FragmentCalls()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        val rootView = inflater.inflate(R.layout.activity_recycler, container, false)
        val recyclerView: RecyclerView =rootView.findViewById(R.id.recyclercall)
        recyclerView.layoutManager= LinearLayoutManager(activity, LinearLayout.VERTICAL, false)

        val intent = Intent (getActivity(), ActivityRecycler::class.java)
        getActivity()!!.startActivity(intent)



        return rootView
}

}