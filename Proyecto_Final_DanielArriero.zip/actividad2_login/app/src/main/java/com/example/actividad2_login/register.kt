package com.example.actividad2_login

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class register : AppCompatActivity() {

    private lateinit var et_user_name2 : EditText
    private lateinit var et_password2 : EditText
    private lateinit var et_nacionalidad2 : EditText
    private lateinit var et_edad2 : EditText
    private lateinit var bt_register2 : Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        initElements()
    }

    private fun initElements(){
        et_user_name2 = findViewById(R.id.et_user_name2)
        et_password2 = findViewById(R.id.et_password2)
        et_nacionalidad2 = findViewById(R.id.et_nacionalidad2)
        et_edad2 = findViewById(R.id.et_edad2)
        bt_register2 = findViewById(R.id.bt_register2)

        bt_register2.setOnClickListener{
            if(dataValidator(et_user_name2.text.toString(),et_password2.text.toString(),et_nacionalidad2.text.toString(),et_edad2.text.toString())){
                var editor = getSharedPreferences("dataUser", MODE_PRIVATE).edit()
                editor.putString("user",et_user_name2.text.toString())
                editor.putString("pass", et_password2.text.toString())
                editor.putString("city", et_nacionalidad2.text.toString())
                editor.putString("age",et_edad2.text.toString())
                editor.commit()
                Toast.makeText(this, "Registro exitoso", Toast.LENGTH_SHORT).show()
                this.finish()
            }
            else{
                Toast.makeText(this, "No puedes dejar campos vacíos",Toast.LENGTH_SHORT).show()
            }
        }

    }

    fun dataValidator(user:String, pass: String, city: String, age: String): Boolean{
        if( user.length >0 && pass.length >0 && city.length > 0 && age.length >0){
            return true
        }
        return false
    }
}