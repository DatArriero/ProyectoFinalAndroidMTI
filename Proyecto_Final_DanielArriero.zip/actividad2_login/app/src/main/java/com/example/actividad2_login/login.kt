package com.example.actividad2_login

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class login : AppCompatActivity() {

    private lateinit var et_user_name : EditText
    private lateinit var et_user_password : EditText
    private lateinit var login : Button
    private lateinit var registrar : Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        initElements()
    }

    private fun initElements(){

        et_user_name = findViewById(R.id.et_user_name)
        et_user_password = findViewById(R.id.et_user_password)
        registrar = findViewById(R.id.registrar)
        login = findViewById(R.id.login)

        login.setOnClickListener{
            if(validator(et_user_name.text.toString(),et_user_password.text.toString())){
                var intent = Intent(this, FragmentActivity ::class.java)

                var name = et_user_name.text.toString()

                intent.putExtra("name", name)

                startActivity(intent)

            }
            else{
                Toast.makeText(this, "Usuario o contraseña invalidos", Toast.LENGTH_SHORT).show()
                et_user_name.setText("")
                et_user_password.setText("")
            }
        }


        registrar.setOnClickListener{
                var intent = Intent(this, register ::class.java)
                startActivity(intent)

        }

            }

    private fun validator(user: String, password: String): Boolean{
        var prefs = getSharedPreferences("dataUser", MODE_PRIVATE)
        val name = prefs.getString("user", "Daniel Arriero")
        val pass = prefs.getString("pass", "160306")
        if(user.equals(name) && password.equals(pass)){
            return true
        }
        return false
    }
}
