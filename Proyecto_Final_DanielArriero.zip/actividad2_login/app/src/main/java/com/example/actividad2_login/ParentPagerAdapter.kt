package com.example.actividad2_login

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter

class ParentPagerAdapter(manager: FragmentManager): FragmentPagerAdapter(manager) {
    override fun getItem(position: Int): Fragment {
        return when(position){
            0 -> FragmentChats.newInstance()
            1 -> FragmentStatus.newInstance()
            else -> FragmentCalls.newInstance()
        }
    }

    // Tabs que vamos a tener
    override fun getCount(): Int {
        return 3
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return when(position){
            0 -> "chats"
            1 -> "status"
            else -> "calls"
        }
    }

}