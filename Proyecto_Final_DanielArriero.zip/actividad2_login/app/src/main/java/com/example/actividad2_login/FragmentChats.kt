package com.example.actividad2_login

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout



class FragmentChats : Fragment() {

    companion object {
        fun newInstance(): FragmentChats{
            return FragmentChats()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        val rootView = inflater.inflate(R.layout.fragment_chats, container, false)
        val recyclerView: RecyclerView =rootView.findViewById(R.id.recyclerchats)
        recyclerView.layoutManager= LinearLayoutManager(activity, LinearLayout.VERTICAL, false)


        val conversaciones=ArrayList<Conversaciones>()
        conversaciones.add(Conversaciones("Amoshote", "Ya vienes a Casa","10:32pm", R.drawable.foto1))
        conversaciones.add(Conversaciones("Aniela", "Tuve Examen Papa","13:50pm", R.drawable.foto2))
        conversaciones.add(Conversaciones("Jenny", "Vamos a Cenar","9:17pm", R.drawable.foto3))
        conversaciones.add(Conversaciones("Jose", "Vamos por las miller","9:32pm", R.drawable.foto4))
        conversaciones.add(Conversaciones("SubeT", "Vamos a Tener Junta Mañana a las 3","9:35pm", R.drawable.foto5))
        conversaciones.add(Conversaciones("3399234567", "somos de Coppel","9:40pm", R.drawable.foto6))
        conversaciones.add(Conversaciones("Arrieros", "Buenas Noche Familia","9:41pm", R.drawable.foto7))
        conversaciones.add(Conversaciones("Koko", "Que pedo Machine","9:45pm", R.drawable.foto8))


        val adapter=AdapterConversaciones(conversaciones)
        recyclerView.adapter=adapter
        return rootView


    }




}